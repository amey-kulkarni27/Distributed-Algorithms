#pragma once

#include <iostream>
#include <cstring>
#include <arpa/inet.h>

class UDPclient{
	public:
		// Constructor
		UDPclient()

	private:
		
}
